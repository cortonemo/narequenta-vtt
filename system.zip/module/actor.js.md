import { EntitySheetHelper } from "./helper.js";

export class NarequentaActor extends Actor {

  /** @inheritdoc */
  prepareDerivedData() {
    /* ... code ... */
  }

  _prepareEssenceData() {
    /* ... code ... */
  }

  /** @inheritdoc */
  async rollInitiative(createCombatants=true, context={}) {
    /* ... code ... */
  }

  /** @inheritdoc */
  getRollData() {
    /* ... code ... */
  }
}
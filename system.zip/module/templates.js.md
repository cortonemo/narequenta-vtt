export const preloadHandlebarsTemplates = async function() {
  /* ... code ... */
};
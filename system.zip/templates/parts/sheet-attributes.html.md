<section class="attributes-group">
    <ol class="attributes-list">
        {{!-- Loop through individual attributes --}}
        {{#each attributes as |attr key|}}
        <li class="attribute flexrow" data-attribute="...">
            </li>
        {{/each}}
    </ol>
</section>
<form class="{{cssClass}}" autocomplete="off">
    
    {{!-- ================================================================= --}}
    {{!-- HEADER: Identity & Mechanics                                      --}}
    {{!-- ================================================================= --}}
    <header class="sheet-header">
        <div class="header-fields">
            <div class="resource-row">
                </div>
            
            <div class="resource-row">
                </div>
        </div>
    </header>

    {{!-- ================================================================= --}}
    {{!-- NAVIGATION TABS                                                   --}}
    {{!-- Tabs: Description, Details, Attributes                            --}}
    {{!-- ================================================================= --}}
    <nav class="sheet-tabs tabs" data-group="primary">
        </nav>

    {{!-- ================================================================= --}}
    {{!-- SHEET BODY                                                        --}}
    {{!-- ================================================================= --}}
    <section class="sheet-body">

        {{!-- Tab 1: Description --}}
        <div class="tab" data-group="primary" data-tab="description">
            </div>

        {{!-- Tab 2: Details (Costs) --}}
        <div class="tab" data-group="primary" data-tab="details">
            </div>

        {{!-- Tab 3: Attributes (Legacy) --}}
        <div class="tab attributes" data-group="primary" data-tab="attributes">
            </div>
    </section>
</form>